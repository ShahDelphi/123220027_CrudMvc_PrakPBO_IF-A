package controller;
import java.util.List;
import DAOdataPerpus.dataPerpusDAO;
import DAOImplement.dataPerpusImplement;
import model.*;
import view.MainView;

public class dataPerpusController {
    MainView frame;
    dataPerpusImplement impldataPerpus;
    List<dataPerpus> dp;
    
    public dataPerpusController(MainView frame){
        this.frame = frame;
        impldataPerpus = new dataPerpusDAO();
        dp = impldataPerpus.getAll();
    }
    
    public void isitabel(){
        dp = impldataPerpus.getAll();
        Tabel mp = new Tabel(dp);
        frame.getTabelDataPerpus().setModel(mp);
    }
    
     public void insert(){
        dataPerpus dp = new dataPerpus();
        dp.setJudul(frame.getJTxtjudul().getText());
        dp.setGenre(frame.getJTxtgenre().getText());
        dp.setPenulis(frame.getJTxtpenulis().getText());
        dp.setPenerbit(frame.getJTxtpenerbit().getText());
        dp.setLokasi(frame.getJTxtlokasi().getText());
        
        try {
        int stock = Integer.parseInt(frame.getJTxtstock().getText()); // Konversi string ke integer
        dp.setStock(stock);
        impldataPerpus.insert(dp);
        } 
        catch (NumberFormatException e) {
        e.printStackTrace();
        }
        
    }
     
    public void update(){
        dataPerpus dp = new dataPerpus();
        dp.setJudul(frame.getJTxtjudul().getText());
        dp.setGenre(frame.getJTxtgenre().getText());
        dp.setPenulis(frame.getJTxtpenulis().getText());
        dp.setPenerbit(frame.getJTxtpenerbit().getText());
        dp.setLokasi(frame.getJTxtlokasi().getText());

        try {
            int stock = Integer.parseInt(frame.getJTxtstock().getText()); 
            dp.setStock(stock);
        } 
        catch (NumberFormatException e) {
            e.printStackTrace();
            
            return;
        }

        try {
            int id = Integer.parseInt(frame.getJTxtid().getText()); 
            dp.setId(id);
        } 
        catch (NumberFormatException e) {
            e.printStackTrace();
 
            return;
        }

        impldataPerpus.update(dp);
    }
    
    public void delete(){
        int id = Integer.parseInt(frame.getJTxtid().getText());
        impldataPerpus.delete(id);
    }
    
    public void search(String cari) {
        List<dataPerpus> searchResult = impldataPerpus.search(cari);
        Tabel mp = new Tabel(searchResult);
        frame.getTabelDataPerpus().setModel(mp);
    }

}
