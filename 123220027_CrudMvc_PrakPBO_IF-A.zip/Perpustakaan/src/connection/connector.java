package connection;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class connector {
    static Connection connect;
    
    public static Connection connection(){
        if(connect==null){
            MysqlDataSource data = new MysqlDataSource();
            data.setDatabaseName("perpus");
            data.setUser("root");
            data.setPassword("");
            try{
                connect = data.getConnection();
                System.out.println("Koneksi berhasil");
            }catch(SQLException ex){
                ex.printStackTrace();
                System.out.println("Koneksi gagal");
            }
        }
        
        
        return connect;
    }
}
