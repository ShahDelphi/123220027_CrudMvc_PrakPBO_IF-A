package DAOdataPerpus;
import java.sql.*;
import java.util.*;
import connection.connector;
import model.*;
import DAOImplement.dataPerpusImplement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class dataPerpusDAO implements dataPerpusImplement {
    Connection connection;
    
    final String select = "select * from dataperpus;";
    final String insert = "INSERT INTO dataperpus (judul, genre, penulis, penerbit, lokasi, stock) VALUES (?, ?, ?, ?, ?, ?);";
    final String update = "update dataperpus set judul=?, genre=?, penulis=?, penerbit=?, lokasi=?, stock=? where id=?";
    final String delete = "delete from dataperpus where id=?";
    final String search = "SELECT * FROM dataperpus WHERE judul LIKE ? OR genre LIKE ? OR penulis LIKE ? OR penerbit LIKE ? OR lokasi LIKE ?";
    
    public dataPerpusDAO(){
        connection = connector.connection();
    } 

    @Override
    public void insert(dataPerpus p) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, p.getJudul());
            statement.setString(2, p.getGenre());
            statement.setString(3, p.getPenulis());
            statement.setString(4, p.getPenerbit());
            statement.setString(5, p.getLokasi());
            statement.setInt(6, p.getStock());
            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();
            while(rs.next()){
                p.setId(rs.getInt(1));
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void update(dataPerpus p) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(update);
            statement.setString(1, p.getJudul());
            statement.setString(2, p.getGenre());
            statement.setString(3, p.getPenulis());
            statement.setString(4, p.getPenerbit());
            statement.setString(5, p.getLokasi());
            statement.setInt(6, p.getStock());
            statement.setInt(7, p.getId());
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void delete(int id) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(delete);
            
            statement.setInt(1, id);
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<dataPerpus> getAll() {
        List<dataPerpus> dp = null;
        try{
            dp = new ArrayList<dataPerpus>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while(rs.next()){
                dataPerpus perpus = new dataPerpus();
                perpus.setId(rs.getInt("id"));
                perpus.setJudul(rs.getString("judul"));
                perpus.setGenre(rs.getString("genre"));
                perpus.setPenulis(rs.getString("penulis"));
                perpus.setPenerbit(rs.getString("penerbit"));
                perpus.setLokasi(rs.getString("lokasi"));
                perpus.setStock(rs.getInt("stock"));
                dp.add(perpus);
                
            }
        }catch(SQLException ex){
            Logger.getLogger(dataPerpusDAO.class.getName()).log(Level.SEVERE, null,ex);
        }
        
        return dp;
    }
    
    @Override
    public List<dataPerpus> search(String cari) {
        List<dataPerpus> searchResult = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement(search)) {
            // Mengisi parameter dengan nilai yang sesuai
            for (int i = 1; i <= 5; i++) {
                statement.setString(i, "%" + cari + "%");
            }

            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                dataPerpus perpus = new dataPerpus();
                perpus.setId(rs.getInt("id"));
                perpus.setJudul(rs.getString("judul"));
                perpus.setGenre(rs.getString("genre"));
                perpus.setPenulis(rs.getString("penulis"));
                perpus.setPenerbit(rs.getString("penerbit"));
                perpus.setLokasi(rs.getString("lokasi"));
                perpus.setStock(rs.getInt("stock"));
                searchResult.add(perpus);
            }
        } 
        catch (SQLException ex) {
            Logger.getLogger(dataPerpusDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return searchResult;
    }
    
}
