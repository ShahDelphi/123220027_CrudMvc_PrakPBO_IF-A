package DAOImplement;
import java.util.List;
import model.*;

public interface dataPerpusImplement {
    public void insert(dataPerpus p);
    public void update(dataPerpus p);
    public void delete(int id);
    public List<dataPerpus> getAll();
    public List<dataPerpus> search(String cari);
}
